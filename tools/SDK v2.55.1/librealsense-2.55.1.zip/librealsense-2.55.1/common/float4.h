// License: Apache 2.0. See LICENSE file in root directory.
// Copyright(c) 2021 Intel Corporation. All Rights Reserved.

#pragma once

namespace rs2 {


struct float4
{
    float x, y, z, w;
};


}
